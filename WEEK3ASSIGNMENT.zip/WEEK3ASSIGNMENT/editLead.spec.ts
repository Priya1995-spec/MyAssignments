import { test,expect } from '@playwright/test';
test ("CreatingLead" , async({page})=>
{
    await page.goto("http://leaftaps.com/opentaps/control/main")
    await page.locator("#username").fill("DemoSalesManager")
    await page.locator("#password").fill("crmsfa")
    await page.locator(".decorativeSubmit").click()
await page.waitForTimeout(5000)
await page.locator("//a[contains(text(),'CRM/SFA')]").click()
await page.waitForTimeout(5000)
await page.locator("//a[contains(text(),'Leads')]").click()
//await page.locator("//a[contains(text(),'Create Lead')]").click()
await page.locator("//a[contains(text(),'Find Leads')]").click()
await page.locator("//input[@id='ext-gen248']").fill("Geetha")
await page.locator("//button[contains(text(),'Find Leads')]").click()
await page.waitForTimeout(5000)
const leadID = await page.locator("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").first().textContent()
console.log("Lead ID is: " + leadID)
await page.locator("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").first().click()
await page.locator("//a[contains(text(),'Edit')]").click()
await page.locator("//input[@id='updateLeadForm_companyName']").clear
await page.locator("//input[@id='updateLeadForm_companyName']").fill("CTS")
await page.locator("//input[@id='updateLeadForm_annualRevenue']").clear
await page.waitForTimeout(2000)
await page.locator("//input[@id='updateLeadForm_annualRevenue']").fill("20000000")
await page.locator("//input[@id='updateLeadForm_departmentName']").clear
await page.waitForTimeout(2000)
await page.locator("//input[@id='updateLeadForm_departmentName']").fill("Testing")
await page.locator("//textarea[@id='updateLeadForm_description']").fill("This is a testing profile")
await page.waitForTimeout(2000)
await page.locator("//input[@id='ext-gen600']").click()
await page.waitForTimeout(30000)
console.log("Lead edited successfully")         

}
)